import './App.css';
import ShopHomePage from './Components/ShopHomePage';

function App() {
  return (
    <div>
      <ShopHomePage/>
    </div>
  );
}

export default App;
